<x-layout>
    <x-slot:title>Dashboard</x-slot:title>

    <div class="row row-deck row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                </div>
            </div>
        </div>
    </div>
</x-layout>
