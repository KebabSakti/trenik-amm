<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Edit Karyawan <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="row card-body">
                    <div class="col-lg-5 col-12">
                        <form method="post" action="<?php echo e(route('employee.update', $employee->user_id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Email"
                                    value="<?php echo e($employee->email); ?>" required>
                                <small class="text-danger">* Digunakan untuk email login</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Password">
                                <small class="text-danger">* Kosongkan jika tidak mengganti password</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">NIK</label>
                                <input type="text" class="form-control" name="nik" placeholder="NIK"
                                    value="<?php echo e($employee->nik); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Nama</label>
                                <input type="text" class="form-control" name="employee_name"
                                    placeholder="Nama karyawan" value="<?php echo e($employee->employee_name); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">KTP</label>
                                <input type="text" class="form-control" name="ktp" placeholder="KTP"
                                    value="<?php echo e($employee->ktp); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Telp</label>
                                <input type="text" class="form-control" name="phone" placeholder="Telp"
                                    value="<?php echo e($employee->phone); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Department</label>
                                <select name="department_id" class="form-select" required>
                                    <option value=""> - Pilih Department - </option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $selected = $employee->department_id == $department->id ? 'selected' : '';
                                        ?>

                                        <option value="<?php echo e($department->id); ?>" <?php echo e($selected); ?>>
                                            <?php echo e($department->department_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Jabatan</label>
                                <select name="position_id" class="form-select" required>
                                    <option value=""> - Pilih Jabatan - </option>
                                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $selected = $employee->position_id == $position->id ? 'selected' : '';
                                        ?>

                                        <option value="<?php echo e($position->id); ?>" <?php echo e($selected); ?>>
                                            <?php echo e($position->position_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Grade</label>
                                <select name="grade_id" class="form-select" required>
                                    <option value=""> - Pilih Grade - </option>
                                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $selected = $employee->grade_id == $grade->id ? 'selected' : '';
                                        ?>

                                        <option value="<?php echo e($grade->id); ?>" <?php echo e($selected); ?>>
                                            <?php echo e($grade->grade_name); ?>

                                            (Rp.<?php echo e(number_format($grade->max_credit, 2, ',', '.')); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Level</label>
                                <select name="role" class="form-select" required>
                                    <?php
                                        $roles = [
                                            [
                                                'key' => 'user',
                                                'value' => 'User (Normal User)',
                                            ],
                                            [
                                                'key' => 'pic',
                                                'value' => 'PIC (Person In Charge)',
                                            ],
                                        ];
                                    ?>

                                    <option value=""> - Level Akun - </option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $selected = $employee->role == $role['key'] ? 'selected' : '';
                                        ?>

                                        <option value="<?php echo e($role['key']); ?>" <?php echo e($selected); ?>>
                                            <?php echo e($role['value']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <div class="form-label">Status</div>
                                <label class="form-check form-switch">
                                    <?php
                                        $checked = $employee->active == 1 ? 'checked' : '';
                                    ?>

                                    <input class="form-check-input" type="checkbox" name="active" <?php echo e($checked); ?>>
                                    <span class="form-check-label"></span>
                                </label>
                            </div>
                            <div class="form-footer">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">Batal</a>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/employee/edit.blade.php ENDPATH**/ ?>