<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Detail Barang <?php $__env->endSlot(); ?>

    <!-- Modal -->
    <?php if (isset($component)) { $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ModalForm::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ModalForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('id', null, []); ?> pengajuan-modal <?php $__env->endSlot(); ?>
         <?php $__env->slot('title', null, []); ?> Form Pengajuan <?php $__env->endSlot(); ?>
        <form method="post" action="<?php echo e(route('submission.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <div class="mb-3">
                <label class="form-label">Nama Barang</label>
                <input type="text" class="form-control" value="<?php echo e($product->product_name); ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Skema Kredit</label>
                <select name="credit_scheme_id" class="form-select" required>
                    <option value=""> - Pilih Cicilan - </option>
                    <?php $__currentLoopData = $credit_schemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit_scheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($credit_scheme->id); ?>">
                        <?php echo e($credit_scheme->count); ?>x | Harga : Rp
                        <?php echo e(number_format($credit_scheme->price, 2, ',', '.')); ?> | Bulanan : Rp
                        <?php echo e(number_format($credit_scheme->credit, 2, ',', '.')); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Foto</label>
                <input type="file" class="form-control" name="foto" placeholder="Foto" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Mine Permit</label>
                <input type="file" class="form-control" name="permit" placeholder="Mine Permit" required>
            </div>
            <div class="mb-3">
                <label class="form-check">
                    <input class="form-check-input" type="checkbox" name="consent" required>
                    <span class="form-check-label">Saya setuju dengan <a href="#" target="_blank">Syarat &
                            Ketentuan</a></span>
                </label>
            </div>
            <div class="form-footer">
                <button type="submit" class="btn btn-primary">Buat Pengajuan</button>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce)): ?>
<?php $component = $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce; ?>
<?php unset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column flex-md-row">
                        <div class="mb-3 me-3" style="max-width: 400px;">
                            <img src="<?php echo e(asset($product->product_image)); ?>" class="img-fluid">
                        </div>
                        <div>
                            <?php if(!$submitable): ?>
                            <div class="alert alert-danger" role="alert">
                                <h4 class="alert-title">Tidak Bisa Pengajuan Kredit</h4>
                                <div class="text-muted">
                                    Anda memiliki cicilan yang belum selesai, atau anda memiliki pengajuan dengan status
                                    pending
                                </div>
                            </div>
                            <?php endif; ?>
                            <h1><?php echo e($product->product_name); ?></h1>
                            <h3><?php echo e($product->product_brand); ?></h3>
                            <p>
                                <?php echo e($product->product_description); ?>

                            </p>
                            <table class="table table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Cicilan</th>
                                        <th>Harga Jual</th>
                                        <th>Bulanan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $credit_schemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit_scheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($credit_scheme->count); ?>x
                                        </td>
                                        <td>
                                            Rp <?php echo e(number_format($credit_scheme->price, 2, ',', '.')); ?>

                                        </td>
                                        <td>
                                            Rp <?php echo e(number_format($credit_scheme->credit, 2, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">Kembali</a>
                            <?php if($submitable): ?>
                            <a href="#" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#pengajuan-modal">Ajukan Cicilan</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/barang/show.blade.php ENDPATH**/ ?>