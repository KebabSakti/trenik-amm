<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Edit Skema Kredit <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="row card-body">
                    <div class="col-lg-5 col-12">
                        <form method="post" action="<?php echo e(route('credit_scheme.update', $product->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label class="form-label">Nama Barang</label>
                                <select class="form-select" name="product_id">
                                    <option value="<?php echo e($product->id); ?>" selected>
                                        <?php echo e($product->product_name); ?>

                                    </option>
                                </select>
                            </div>
                            <?php for($i = 0; $i < count($credit); $i++): ?>
                                <input type="hidden" name="ids[]" value="<?php echo e($credit[$i]->id); ?>">
                                <input type="hidden" name="counts[]" value="<?php echo e($credit[$i]->count); ?>">
                                <div class="row mb-3">
                                    <div class="col">
                                        <label class="form-label">Harga Jual</label>
                                        <input type="number" min="0" class="form-control" name="prices[]"
                                            placeholder="Harga jual" value="<?php echo e($credit[$i]->price); ?>" required>
                                    </div>
                                    <div class="col">
                                        <label class="form-label">Cicilan <?php echo e($credit[$i]->count); ?>x</label>
                                        <input type="number" min="0" class="form-control" name="credits[]"
                                            placeholder="Cicilan <?php echo e($credit[$i]->count); ?>x"
                                            value="<?php echo e($credit[$i]->credit); ?>" required>
                                    </div>
                                </div>
                            <?php endfor; ?>
                            <div class="form-footer">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">Batal</a>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/credit_scheme/edit.blade.php ENDPATH**/ ?>