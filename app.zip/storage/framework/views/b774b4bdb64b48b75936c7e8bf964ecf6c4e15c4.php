<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Sign in - Tronik AMM</title>
    <!-- Icon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(env('APP_PATH') . 'static/favicon.ico'); ?>" />
    <!-- CSS files -->
    <link href="<?php echo e(env('APP_PATH') . 'dist/css/tabler.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo e(env('APP_PATH') . 'dist/css/tabler-flags.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo e(env('APP_PATH') . 'dist/css/tabler-payments.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo e(env('APP_PATH') . 'dist/css/tabler-vendors.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo e(env('APP_PATH') . 'dist/css/demo.min.css'); ?>" rel="stylesheet" />
</head>

<body class="border-top-wide border-primary d-flex flex-column">
    <div class="page page-center">
        <div class="container-tight py-4">
            <div class="text-center mb-4">
                <a href="." class="navbar-brand navbar-brand-autodark"><img
                        src="<?php echo e(env('APP_PATH') . 'static/logo-top.png'); ?>" height="140" alt=""></a>
            </div>
            <form class="card card-md" action="wizard/authenticate" method="post" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Masukkan kode</label>
                        <input name="access" type="password" class="form-control" placeholder="Kode akses"
                            autocomplete="off" required>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary w-100">Submit</button>
                    </div>
                </div>
            </form>

            <?php if($errors->any()): ?>
                <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('type', null, []); ?> alert-danger <?php $__env->endSlot(); ?>
                         <?php $__env->slot('title', null, []); ?> Error <?php $__env->endSlot(); ?>
                            <?php echo e($errors->first()); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo e(env('APP_PATH') . 'dist/js/tabler.min.js'); ?>" defer></script>
    <script src="<?php echo e(env('APP_PATH') . 'dist/js/demo.min.js'); ?>" defer></script>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/wizard/index.blade.php ENDPATH**/ ?>