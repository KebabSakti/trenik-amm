<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tronik AMM</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/auth.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/favicon.ico')); ?>" type="image/x-icon">
</head>

<body>
    <div id="auth">
        <div class="row d-flex align-items-center justify-content-center h-100">
            <div class="col-10 col-md-5 col-lg-3">
                <div class="d-flex justify-content-center mb-5">
                    <img src="<?php echo e(asset('assets/images/logo/logo-top.png')); ?>" width="200" />
                </div>
                <form method="post" action="<?php echo e(session('wizard_session')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input name="email" type="email" class="form-control form-control-xl" placeholder="Email"
                            required>
                        <div class="form-control-icon">
                            <i class="bi bi-envelope"></i>
                        </div>
                    </div>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input name="password" type="password" class="form-control form-control-xl"
                            placeholder="Password" required>
                        <div class="form-control-icon">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                    </div>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input name="company_name" type="text" class="form-control form-control-xl"
                            placeholder="Nama koperasi" required>
                        <div class="form-control-icon">
                            <i class="bi bi-building"></i>
                        </div>
                    </div>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input name="monthly_balance" type="number" min="0" class="form-control form-control-xl"
                            placeholder="Limit Saldo" required>
                        <div class="form-control-icon">
                            <i class="bi bi-coin"></i>
                        </div>
                    </div>
                    <button class="btn btn-primary btn-block btn-lg shadow-lg mb-4">Submit</button>
                </form>
                <?php if($errors->any()): ?>
                    <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e($errors->first()); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.js')); ?>"></script>

</body>

</html>
<?php /**PATH /var/www/html/resources/views/wizard/add.blade.php ENDPATH**/ ?>