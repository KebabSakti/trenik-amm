<div class="alert <?php echo e($type); ?> alert-dismissible my-2" role="alert">
    <div class="d-flex">
        <div>
            <h4 class="alert-title"><?php echo e($title); ?></h4>
            <div class="text-muted">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
</div>
<?php /**PATH /var/www/html/resources/views/components/alert.blade.php ENDPATH**/ ?>