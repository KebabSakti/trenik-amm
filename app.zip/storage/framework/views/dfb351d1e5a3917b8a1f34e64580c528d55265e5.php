<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Edit Barang <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="row card-body">
                    <div class="col-md-5 col-12">
                        <form method="post" action="<?php echo e(route('product.update', $model->id)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label class="form-label">Nama Barang</label>
                                <input type="text" class="form-control" name="product_name" placeholder="Nama barang"
                                    value="<?php echo e($model->product_name); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Merk Barang</label>
                                <input type="text" class="form-control" name="product_brand" placeholder="Nama merk"
                                    required value="<?php echo e($model->product_brand); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Gambar</label>
                                <input type="file" class="form-control" name="file" placeholder="Gambar barang">
                                <?php if($model->product_image): ?>
                                    <a data-fancybox href="<?php echo e(asset($model->product_image)); ?>">Lihat Gambar</a>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi Barang</label>
                                <textarea type="text" class="form-control" name="product_description" placeholder="Deskripsi barang" rows="10"><?php echo e($model->product_description); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <div class="form-label">Status Barang</div>
                                <label class="form-check form-switch">
                                    <?php
                                        $checked = $model->active == 1 ? 'checked' : '';
                                    ?>
                                    <input class="form-check-input" type="checkbox" name="active" <?php echo e($checked); ?>>
                                </label>
                            </div>
                            <div class="form-footer">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">Batal</a>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/product/edit.blade.php ENDPATH**/ ?>